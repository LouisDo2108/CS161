#include <string>
using namespace std;
#pragma once
#ifndef function_H_
#define function_H_
int maximum_product(int a[], int& size);
bool circular_shift(string a, string b);
bool circular(string a);
#endif