#include <iostream>

using namespace std;

int main(){
    int input, temp = 0, mod, counter = 0, bin = 0;
    cin >> input;
    while(input != 0){
        mod = input % 2;
        temp = temp*10 + mod;
        input /= 2;
        counter++;
    }

    for(int i = 0; i < counter; ++i){
        bin = bin*10 + temp%10;
        temp = temp / 10;
    }
    cout << bin;
    return 0;
}
