#include <iostream>
#include <string>

using namespace std;

int main() {
    int output = 0, temp = 1;
    string input;
    cin >> input;
    while(input.size() > 0) {
        if(input[0] == '1') {
            for(int i = 1; i < input.size(); ++i) {
                temp *= 2;
            }
            input.erase(0,1);
            output += temp;
            temp = 1;
        } else {
            input.erase(0,1);
            continue;
        }
    }
    cout << output;
    return 0;
}
